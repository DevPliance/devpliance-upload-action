---
template_version: 1

control_id: "A.8.19"
control_name: "Installation of software on operational systems"
theme: technological

status: planned                     # implemented | partial | planned | not_applicable
last_reviewed: 2026-07-22           # YYYY-MM-DD — update whenever content changes
review_cycle: annual                # quarterly | biannual | annual

# Systems, services, or repos this control applies to.
# Use the canonical names from your service catalogue.
applies_to:
  - example-service

related_controls: ["A.8.32", "A.8.9"]
tags: [deployment, provenance]
---

# A.8.19 — Installation of software on operational systems

> **Control intent**
>
> Procedures and measures must be in place to securely manage the
> installation of software on operational (production) systems, so that
> only authorised, integrity-checked software runs in production and
> installations are controlled and traceable.

<!--
  Write for two audiences: an auditor who has never seen your system,
  and the engineer who inherits this control next year. Be concrete —
  name the tools, link the configs. These comments are stripped at
  parse time; delete them as you go or leave them, either is fine.
-->

## How we meet this control

<!--
  REQUIRED. Describe what is in place today, present tense. Cover:
    - How software reaches this service's production systems — the only
      path should be the deploy pipeline; describe it and link the
      workflow.
    - Artifact integrity: image digests pinned, artifact
      signing/provenance (SLSA, cosign) if in use.
    - Who and what can trigger a production deploy, and the approval
      required.
-->

## How it is enforced and monitored

<!--
  REQUIRED. Controls that rely on people remembering things fail
  audits. Cover:
    - What prevents out-of-band installation: no SSH to prod, immutable
      images, admission controllers restricting registries.
    - How an unauthorised or unexpected workload would be detected.
-->

## Scope and exclusions

<!--
  REQUIRED. Define the boundary honestly — a clear exclusion reads far
  better than a discovered omission. Consider:
    - Include supporting software: agents, sidecars, cron jobs on hosts —
      anything running in prod that isn't the main artifact.
    - Which environments are covered (prod only? staging too?)
    - Accepted risks, with a link to the risk register entry if one exists.
-->

## Gaps and remediation

<!--
  REQUIRED — write "None identified." if genuinely none.
  Use task-list checkboxes so open items are machine-trackable.
-->

- [ ] Example gap — owner: @username, due: 2026-12-31, tracking: ORG-1234

## Operational notes

<!--
  OPTIONAL. Runbooks, renewal dates, known quirks, past audit findings
  and how they were resolved.
-->

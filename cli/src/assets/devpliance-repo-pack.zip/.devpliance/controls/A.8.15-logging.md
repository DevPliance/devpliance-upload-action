---
template_version: 1

control_id: "A.8.15"
control_name: "Logging"
theme: technological

status: planned                     # implemented | partial | planned | not_applicable
last_reviewed: 2026-07-22           # YYYY-MM-DD — update whenever content changes
review_cycle: annual                # quarterly | biannual | annual

# Systems, services, or repos this control applies to.
# Use the canonical names from your service catalogue.
applies_to:
  - example-service

related_controls: ["A.8.16", "A.8.12"]
tags: [logging, audit-trail]
---

# A.8.15 — Logging

> **Control intent**
>
> Logs recording activities, exceptions, faults and other relevant events
> must be produced, stored, protected from tampering, and analysed, so
> that security events can be reconstructed and accountability
> established.

<!--
  Write for two audiences: an auditor who has never seen your system,
  and the engineer who inherits this control next year. Be concrete —
  name the tools, link the configs. These comments are stripped at
  parse time; delete them as you go or leave them, either is fine.
-->

## How we meet this control

<!--
  REQUIRED. Describe what is in place today, present tense. Cover:
    - What this service logs: security-relevant events (authn/authz
      decisions, admin actions, data access) — not just application debug
      output.
    - Where logs go, retention period per log type, and who can read them.
    - What is deliberately excluded or scrubbed: passwords, tokens, PII
      fields — and the mechanism doing the scrubbing.
-->

## How it is enforced and monitored

<!--
  REQUIRED. Controls that rely on people remembering things fail
  audits. Cover:
    - Log integrity: can the service (or an attacker on it) alter or
      delete its own shipped logs? Append-only sinks, restricted delete
      permissions.
    - Alerting on logging pipeline failure — silence should be an alarm,
      not a gap.
-->

## Scope and exclusions

<!--
  REQUIRED. Define the boundary honestly — a clear exclusion reads far
  better than a discovered omission. Consider:
    - Cover all log sources for the service: app logs, access logs at the
      LB, audit logs of the datastore.
    - Which environments are covered (prod only? staging too?)
    - Accepted risks, with a link to the risk register entry if one exists.
-->

## Gaps and remediation

<!--
  REQUIRED — write "None identified." if genuinely none.
  Use task-list checkboxes so open items are machine-trackable.
-->

- [ ] Example gap — owner: @username, due: 2026-12-31, tracking: ORG-1234

## Operational notes

<!--
  OPTIONAL. Runbooks, renewal dates, known quirks, past audit findings
  and how they were resolved.
-->

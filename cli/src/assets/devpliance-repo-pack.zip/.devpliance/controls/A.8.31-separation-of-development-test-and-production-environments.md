---
template_version: 1

control_id: "A.8.31"
control_name: "Separation of development, test and production environments"
theme: technological

status: planned                     # implemented | partial | planned | not_applicable
last_reviewed: 2026-07-22           # YYYY-MM-DD — update whenever content changes
review_cycle: annual                # quarterly | biannual | annual

# Systems, services, or repos this control applies to.
# Use the canonical names from your service catalogue.
applies_to:
  - example-service

related_controls: ["A.8.32", "A.8.33"]
tags: [environments, separation]
---

# A.8.31 — Separation of development, test and production environments

> **Control intent**
>
> Development, testing and production environments must be separated and
> secured, to reduce the risk of unauthorised access to production,
> accidental changes, and leakage of production data into less protected
> environments.

<!--
  Write for two audiences: an auditor who has never seen your system,
  and the engineer who inherits this control next year. Be concrete —
  name the tools, link the configs. These comments are stripped at
  parse time; delete them as you go or leave them, either is fine.
-->

## How we meet this control

<!--
  REQUIRED. Describe what is in place today, present tense. Cover:
    - The environments this service runs in and how they are separated:
      accounts/projects/namespaces, networks, credentials.
    - The promotion path between them and what approval each promotion
      requires.
    - Identity separation: different IAM roles and secrets per
      environment; no shared credentials.
-->

## How it is enforced and monitored

<!--
  REQUIRED. Controls that rely on people remembering things fail
  audits. Cover:
    - What technically prevents dev workloads reaching prod data (network
      policy, account boundaries, SCPs)?
    - Who has access to production vs. lower environments, and how prod
      access is gated (break-glass, JIT elevation).
-->

## Scope and exclusions

<!--
  REQUIRED. Define the boundary honestly — a clear exclusion reads far
  better than a discovered omission. Consider:
    - Shared components (one CI system, one artifact registry) span
      environments — describe how they are prevented from becoming a
      bridge.
    - Which environments are covered (prod only? staging too?)
    - Accepted risks, with a link to the risk register entry if one exists.
-->

## Gaps and remediation

<!--
  REQUIRED — write "None identified." if genuinely none.
  Use task-list checkboxes so open items are machine-trackable.
-->

- [ ] Example gap — owner: @username, due: 2026-12-31, tracking: ORG-1234

## Operational notes

<!--
  OPTIONAL. Runbooks, renewal dates, known quirks, past audit findings
  and how they were resolved.
-->

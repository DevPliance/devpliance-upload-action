---
template_version: 1

control_id: "A.8.8"
control_name: "Management of technical vulnerabilities"
theme: technological

status: planned                     # implemented | partial | planned | not_applicable
last_reviewed: 2026-07-22           # YYYY-MM-DD — update whenever content changes
review_cycle: annual                # quarterly | biannual | annual

# Systems, services, or repos this control applies to.
# Use the canonical names from your service catalogue.
applies_to:
  - example-service

related_controls: ["A.8.29", "A.8.19"]
tags: [vulnerabilities, patching, sca]
---

# A.8.8 — Management of technical vulnerabilities

> **Control intent**
>
> The organisation must obtain timely information about technical
> vulnerabilities affecting the systems it uses, evaluate its exposure to
> them, and take appropriate measures (patching, mitigation, or accepted
> risk) within defined timescales.

<!--
  Write for two audiences: an auditor who has never seen your system,
  and the engineer who inherits this control next year. Be concrete —
  name the tools, link the configs. These comments are stripped at
  parse time; delete them as you go or leave them, either is fine.
-->

## How we meet this control

<!--
  REQUIRED. Describe what is in place today, present tense. Cover:
    - How vulnerable dependencies are detected: Dependabot/Renovate/Snyk
      config in this repo, container base-image scanning, and how findings
      reach the team.
    - Patching SLAs by severity (e.g. critical 48h, high 7d) and where
      they are defined.
    - How the service's runtime is patched: base image rebuild cadence,
      managed-platform responsibility split.
-->

## How it is enforced and monitored

<!--
  REQUIRED. Controls that rely on people remembering things fail
  audits. Cover:
    - What happens when an SLA is breached — escalation, dashboard, build
      failures on known-critical CVEs.
    - Auto-merge policy for dependency updates and the test gate that
      makes auto-merge safe.
-->

## Scope and exclusions

<!--
  REQUIRED. Define the boundary honestly — a clear exclusion reads far
  better than a discovered omission. Consider:
    - State the responsibility boundary with the platform/cloud provider
      explicitly (their kernel, your container contents).
    - Which environments are covered (prod only? staging too?)
    - Accepted risks, with a link to the risk register entry if one exists.
-->

## Gaps and remediation

<!--
  REQUIRED — write "None identified." if genuinely none.
  Use task-list checkboxes so open items are machine-trackable.
-->

- [ ] Example gap — owner: @username, due: 2026-12-31, tracking: ORG-1234

## Operational notes

<!--
  OPTIONAL. Runbooks, renewal dates, known quirks, past audit findings
  and how they were resolved.
-->

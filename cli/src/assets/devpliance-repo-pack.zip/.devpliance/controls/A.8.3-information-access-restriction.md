---
template_version: 1

control_id: "A.8.3"
control_name: "Information access restriction"
theme: technological

status: planned                     # implemented | partial | planned | not_applicable
last_reviewed: 2026-07-22           # YYYY-MM-DD — update whenever content changes
review_cycle: annual                # quarterly | biannual | annual

# Systems, services, or repos this control applies to.
# Use the canonical names from your service catalogue.
applies_to:
  - example-service

related_controls: ["A.8.4", "A.8.27"]
tags: [authorization, least-privilege]
---

# A.8.3 — Information access restriction

> **Control intent**
>
> Access to information and other associated assets must be restricted
> according to the organisation's access control policy, so that only
> authorised users, processes and systems can reach the data they
> legitimately need — and nothing more.

<!--
  Write for two audiences: an auditor who has never seen your system,
  and the engineer who inherits this control next year. Be concrete —
  name the tools, link the configs. These comments are stripped at
  parse time; delete them as you go or leave them, either is fine.
-->

## How we meet this control

<!--
  REQUIRED. Describe what is in place today, present tense. Cover:
    - How this service restricts access to the information it holds: the
      authz model (RBAC/ABAC, tenant scoping), and where it is enforced
      (middleware, per-query filters).
    - Access restriction for humans: who can read the service's production
      data directly (DB access, admin panels) and via what gate.
    - Least privilege for the service itself: IAM scoping of what this
      service can read from other systems.
-->

## How it is enforced and monitored

<!--
  REQUIRED. Controls that rely on people remembering things fail
  audits. Cover:
    - Tests that prove restriction: per-endpoint authz tests, tenant-
      isolation tests in CI.
    - Reviews of direct data access grants and admin-panel roles — cadence
      and record.
-->

## Scope and exclusions

<!--
  REQUIRED. Define the boundary honestly — a clear exclusion reads far
  better than a discovered omission. Consider:
    - Exports, reports and APIs are access paths too — cover every way
      data leaves the service, not just the primary UI.
    - Which environments are covered (prod only? staging too?)
    - Accepted risks, with a link to the risk register entry if one exists.
-->

## Gaps and remediation

<!--
  REQUIRED — write "None identified." if genuinely none.
  Use task-list checkboxes so open items are machine-trackable.
-->

- [ ] Example gap — owner: @username, due: 2026-12-31, tracking: ORG-1234

## Operational notes

<!--
  OPTIONAL. Runbooks, renewal dates, known quirks, past audit findings
  and how they were resolved.
-->

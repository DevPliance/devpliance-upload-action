---
template_version: 1

control_id: "A.8.25"
control_name: "Secure development life cycle"
theme: technological

status: planned                     # implemented | partial | planned | not_applicable
last_reviewed: 2026-07-22           # YYYY-MM-DD — update whenever content changes
review_cycle: annual                # quarterly | biannual | annual

# Systems, services, or repos this control applies to.
# Use the canonical names from your service catalogue.
applies_to:
  - example-service

related_controls: ["A.8.26", "A.8.28", "A.8.29", "A.8.32"]
tags: [sdlc, process]
---

# A.8.25 — Secure development life cycle

> **Control intent**
>
> Rules for the secure development of software and systems must be
> established and applied, embedding security into the development process
> itself rather than bolting it on afterwards.

<!--
  Write for two audiences: an auditor who has never seen your system,
  and the engineer who inherits this control next year. Be concrete —
  name the tools, link the configs. These comments are stripped at
  parse time; delete them as you go or leave them, either is fine.
-->

## How we meet this control

<!--
  REQUIRED. Describe what is in place today, present tense. Cover:
    - The end-to-end path a change takes in this repo: issue → branch → PR
      → review → CI gates → merge → deploy.
    - The security checkpoints in that path and where each is defined
      (branch protection, CI workflow files).
    - Rules for review: how many approvals, who can approve, self-approval
      allowed or not.
-->

## How it is enforced and monitored

<!--
  REQUIRED. Controls that rely on people remembering things fail
  audits. Cover:
    - Which gates are hard blocks vs. advisory warnings — be honest,
      auditors will test this.
    - How the workflow files defining the gates are themselves protected
      from being edited to skip the gates.
-->

## Scope and exclusions

<!--
  REQUIRED. Define the boundary honestly — a clear exclusion reads far
  better than a discovered omission. Consider:
    - Hotfix / emergency path: does it skip any gate, and what
      compensating control applies (post-hoc review)?
    - Does this cover all branches that can reach production, including
      release/* branches?
    - Which environments are covered (prod only? staging too?)
    - Accepted risks, with a link to the risk register entry if one exists.
-->

## Gaps and remediation

<!--
  REQUIRED — write "None identified." if genuinely none.
  Use task-list checkboxes so open items are machine-trackable.
-->

- [ ] Example gap — owner: @username, due: 2026-12-31, tracking: ORG-1234

## Operational notes

<!--
  OPTIONAL. Runbooks, renewal dates, known quirks, past audit findings
  and how they were resolved.
-->

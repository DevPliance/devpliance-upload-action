---
template_version: 1

control_id: "A.8.16"
control_name: "Monitoring activities"
theme: technological

status: planned                     # implemented | partial | planned | not_applicable
last_reviewed: 2026-07-22           # YYYY-MM-DD — update whenever content changes
review_cycle: annual                # quarterly | biannual | annual

# Systems, services, or repos this control applies to.
# Use the canonical names from your service catalogue.
applies_to:
  - example-service

related_controls: ["A.8.15"]
tags: [monitoring, alerting]
---

# A.8.16 — Monitoring activities

> **Control intent**
>
> Networks, systems and applications must be monitored for anomalous
> behaviour, and appropriate action taken to evaluate potential security
> incidents — detection, not just recording.

<!--
  Write for two audiences: an auditor who has never seen your system,
  and the engineer who inherits this control next year. Be concrete —
  name the tools, link the configs. These comments are stripped at
  parse time; delete them as you go or leave them, either is fine.
-->

## How we meet this control

<!--
  REQUIRED. Describe what is in place today, present tense. Cover:
    - Security-relevant monitoring for this service: what anomalies or
      events raise alerts (auth failure spikes, unusual data access
      volume, WAF hits).
    - The dashboards and alert routes: where alerts go, who is on call,
      response expectations.
    - Detection content source: hand-written rules in this repo, or a
      central SIEM/detection team consuming this service's logs.
-->

## How it is enforced and monitored

<!--
  REQUIRED. Controls that rely on people remembering things fail
  audits. Cover:
    - How alert health is verified — periodic test alerts, detection
      reviews, alert-fatigue tuning with a record of what was tuned out
      and why.
    - Coverage review: when new features add new event types, what ensures
      monitoring keeps up?
-->

## Scope and exclusions

<!--
  REQUIRED. Define the boundary honestly — a clear exclusion reads far
  better than a discovered omission. Consider:
    - Be explicit about the split between service-team monitoring (this
      file) and central SOC monitoring (org control) so nothing falls
      between.
    - Which environments are covered (prod only? staging too?)
    - Accepted risks, with a link to the risk register entry if one exists.
-->

## Gaps and remediation

<!--
  REQUIRED — write "None identified." if genuinely none.
  Use task-list checkboxes so open items are machine-trackable.
-->

- [ ] Example gap — owner: @username, due: 2026-12-31, tracking: ORG-1234

## Operational notes

<!--
  OPTIONAL. Runbooks, renewal dates, known quirks, past audit findings
  and how they were resolved.
-->

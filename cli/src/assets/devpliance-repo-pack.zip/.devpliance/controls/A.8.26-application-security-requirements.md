---
template_version: 1

control_id: "A.8.26"
control_name: "Application security requirements"
theme: technological

status: planned                     # implemented | partial | planned | not_applicable
last_reviewed: 2026-07-22           # YYYY-MM-DD — update whenever content changes
review_cycle: annual                # quarterly | biannual | annual

# Systems, services, or repos this control applies to.
# Use the canonical names from your service catalogue.
applies_to:
  - example-service

related_controls: ["A.8.25", "A.8.27"]
tags: [requirements, threat-modelling]
---

# A.8.26 — Application security requirements

> **Control intent**
>
> Information security requirements must be identified, specified and
> approved when developing or acquiring applications, so that security
> needs are known and designed in before a feature or system is built.

<!--
  Write for two audiences: an auditor who has never seen your system,
  and the engineer who inherits this control next year. Be concrete —
  name the tools, link the configs. These comments are stripped at
  parse time; delete them as you go or leave them, either is fine.
-->

## How we meet this control

<!--
  REQUIRED. Describe what is in place today, present tense. Cover:
    - How security requirements are captured for new features in this
      service — security section in the design doc template, threat
      modelling sessions, abuse-case tickets.
    - The trigger: which kinds of change require security requirements
      analysis (new endpoints, new data categories, new integrations)?
    - Where the outputs live (design docs, ADRs, ticket labels) so they
      can be found later.
-->

## How it is enforced and monitored

<!--
  REQUIRED. Controls that rely on people remembering things fail
  audits. Cover:
    - What stops a feature shipping without this analysis — a PR checklist
      item, a required design-review stage, a security label gate?
    - Who is accountable for saying 'this change needs a threat model' —
      the author, the reviewer, or a security team triage?
-->

## Scope and exclusions

<!--
  REQUIRED. Define the boundary honestly — a clear exclusion reads far
  better than a discovered omission. Consider:
    - Small changes are typically exempt — define the threshold explicitly
      rather than leaving it to judgement.
    - Which environments are covered (prod only? staging too?)
    - Accepted risks, with a link to the risk register entry if one exists.
-->

## Gaps and remediation

<!--
  REQUIRED — write "None identified." if genuinely none.
  Use task-list checkboxes so open items are machine-trackable.
-->

- [ ] Example gap — owner: @username, due: 2026-12-31, tracking: ORG-1234

## Operational notes

<!--
  OPTIONAL. Runbooks, renewal dates, known quirks, past audit findings
  and how they were resolved.
-->

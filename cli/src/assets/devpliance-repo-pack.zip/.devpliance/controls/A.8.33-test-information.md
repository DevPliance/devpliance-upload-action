---
template_version: 1

control_id: "A.8.33"
control_name: "Test information"
theme: technological

status: planned                     # implemented | partial | planned | not_applicable
last_reviewed: 2026-07-22           # YYYY-MM-DD — update whenever content changes
review_cycle: annual                # quarterly | biannual | annual

# Systems, services, or repos this control applies to.
# Use the canonical names from your service catalogue.
applies_to:
  - example-service

related_controls: ["A.8.31", "A.8.11"]
tags: [test-data, anonymisation]
---

# A.8.33 — Test information

> **Control intent**
>
> Test information must be appropriately selected, protected and managed,
> so that testing is effective without exposing production or personal
> data to the weaker protections of test environments.

<!--
  Write for two audiences: an auditor who has never seen your system,
  and the engineer who inherits this control next year. Be concrete —
  name the tools, link the configs. These comments are stripped at
  parse time; delete them as you go or leave them, either is fine.
-->

## How we meet this control

<!--
  REQUIRED. Describe what is in place today, present tense. Cover:
    - What data this repo's tests use: synthetic fixtures, generated data,
      anonymised prod extracts, or (be honest) raw production data.
    - If prod-derived data is used anywhere, the anonymisation/masking
      applied and who approves the extract.
    - How test data containing realistic values is protected (not
      committed to the repo, access-controlled test databases).
-->

## How it is enforced and monitored

<!--
  REQUIRED. Controls that rely on people remembering things fail
  audits. Cover:
    - Checks that stop real data leaking into fixtures — secret scanning,
      PII-pattern checks on test directories, review rules.
    - Lifecycle: how stale test datasets are deleted or refreshed.
-->

## Scope and exclusions

<!--
  REQUIRED. Define the boundary honestly — a clear exclusion reads far
  better than a discovered omission. Consider:
    - Cover all test tiers: unit fixtures, integration environments, load-
      test datasets, and demo/sandbox environments.
    - Which environments are covered (prod only? staging too?)
    - Accepted risks, with a link to the risk register entry if one exists.
-->

## Gaps and remediation

<!--
  REQUIRED — write "None identified." if genuinely none.
  Use task-list checkboxes so open items are machine-trackable.
-->

- [ ] Example gap — owner: @username, due: 2026-12-31, tracking: ORG-1234

## Operational notes

<!--
  OPTIONAL. Runbooks, renewal dates, known quirks, past audit findings
  and how they were resolved.
-->

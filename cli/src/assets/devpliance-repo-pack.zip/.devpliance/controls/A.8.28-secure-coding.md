---
template_version: 1

control_id: "A.8.28"
control_name: "Secure coding"
theme: technological

status: planned                     # implemented | partial | planned | not_applicable
last_reviewed: 2026-07-22           # YYYY-MM-DD — update whenever content changes
review_cycle: annual                # quarterly | biannual | annual

# Systems, services, or repos this control applies to.
# Use the canonical names from your service catalogue.
applies_to:
  - example-service

related_controls: ["A.8.25", "A.8.29"]
tags: [sast, linting, standards]
---

# A.8.28 — Secure coding

> **Control intent**
>
> Secure coding principles must be applied to software development,
> reducing the number of exploitable vulnerabilities introduced in code
> before it ever reaches testing or production.

<!--
  Write for two audiences: an auditor who has never seen your system,
  and the engineer who inherits this control next year. Be concrete —
  name the tools, link the configs. These comments are stripped at
  parse time; delete them as you go or leave them, either is fine.
-->

## How we meet this control

<!--
  REQUIRED. Describe what is in place today, present tense. Cover:
    - The coding standards that apply to this repo and where they are
      defined (org standard, language style guide, lint config in-repo).
    - SAST and linting tooling running in CI — name the tools and link the
      workflow files.
    - Language/framework-specific protections in use: ORM
      parameterisation, output encoding, CSRF middleware, memory-safety
      choices.
-->

## How it is enforced and monitored

<!--
  REQUIRED. Controls that rely on people remembering things fail
  audits. Cover:
    - Which findings block a merge vs. get logged — severity thresholds,
      baseline/suppression policy and who can approve a suppression.
    - How rules stay current: tool version pinning and update cadence,
      adoption of new rule sets.
-->

## Scope and exclusions

<!--
  REQUIRED. Define the boundary honestly — a clear exclusion reads far
  better than a discovered omission. Consider:
    - Generated code, vendored dependencies, and test code — state whether
      the same rules apply.
    - Which environments are covered (prod only? staging too?)
    - Accepted risks, with a link to the risk register entry if one exists.
-->

## Gaps and remediation

<!--
  REQUIRED — write "None identified." if genuinely none.
  Use task-list checkboxes so open items are machine-trackable.
-->

- [ ] Example gap — owner: @username, due: 2026-12-31, tracking: ORG-1234

## Operational notes

<!--
  OPTIONAL. Runbooks, renewal dates, known quirks, past audit findings
  and how they were resolved.
-->

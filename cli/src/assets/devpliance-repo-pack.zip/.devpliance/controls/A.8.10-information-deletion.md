---
template_version: 1

control_id: "A.8.10"
control_name: "Information deletion"
theme: technological

status: planned                     # implemented | partial | planned | not_applicable
last_reviewed: 2026-07-22           # YYYY-MM-DD — update whenever content changes
review_cycle: annual                # quarterly | biannual | annual

# Systems, services, or repos this control applies to.
# Use the canonical names from your service catalogue.
applies_to:
  - example-service

related_controls: ["A.8.13", "A.8.11"]
tags: [retention, deletion]
---

# A.8.10 — Information deletion

> **Control intent**
>
> Information stored in systems, devices or other media must be deleted
> when it is no longer required, to prevent unnecessary exposure of
> sensitive data and to satisfy legal, regulatory and contractual
> retention obligations.

<!--
  Write for two audiences: an auditor who has never seen your system,
  and the engineer who inherits this control next year. Be concrete —
  name the tools, link the configs. These comments are stripped at
  parse time; delete them as you go or leave them, either is fine.
-->

## How we meet this control

<!--
  REQUIRED. Describe what is in place today, present tense. Cover:
    - The retention rules that apply to data this service holds, per data
      category, and where they are defined.
    - The deletion mechanisms: automated retention jobs, deletion
      endpoints for customer/DSAR requests — link the code.
    - What deletion actually does: hard delete, soft delete then purge
      (with the purge window), or crypto-shredding.
-->

## How it is enforced and monitored

<!--
  REQUIRED. Controls that rely on people remembering things fail
  audits. Cover:
    - Verification that deletion works end-to-end, including in backups,
      replicas, caches, search indexes and logs — this is where most
      deletion stories fall apart; be precise.
    - Monitoring or tests on the retention jobs so silent failure is
      caught.
-->

## Scope and exclusions

<!--
  REQUIRED. Define the boundary honestly — a clear exclusion reads far
  better than a discovered omission. Consider:
    - State the backup interaction honestly: deleted data typically
      persists in backups until expiry — give the window and reference
      A.8.13.
    - Which environments are covered (prod only? staging too?)
    - Accepted risks, with a link to the risk register entry if one exists.
-->

## Gaps and remediation

<!--
  REQUIRED — write "None identified." if genuinely none.
  Use task-list checkboxes so open items are machine-trackable.
-->

- [ ] Example gap — owner: @username, due: 2026-12-31, tracking: ORG-1234

## Operational notes

<!--
  OPTIONAL. Runbooks, renewal dates, known quirks, past audit findings
  and how they were resolved.
-->

---
template_version: 1

control_id: "A.8.9"
control_name: "Configuration management"
theme: technological

status: planned                     # implemented | partial | planned | not_applicable
last_reviewed: 2026-07-22           # YYYY-MM-DD — update whenever content changes
review_cycle: annual                # quarterly | biannual | annual

# Systems, services, or repos this control applies to.
# Use the canonical names from your service catalogue.
applies_to:
  - example-service

related_controls: ["A.8.32", "A.8.19"]
tags: [configuration, iac]
---

# A.8.9 — Configuration management

> **Control intent**
>
> Configurations of hardware, software, services and networks — including
> security configurations — must be established, documented, implemented,
> monitored and reviewed, so systems run in a known, hardened state rather
> than accumulating undocumented drift.

<!--
  Write for two audiences: an auditor who has never seen your system,
  and the engineer who inherits this control next year. Be concrete —
  name the tools, link the configs. These comments are stripped at
  parse time; delete them as you go or leave them, either is fine.
-->

## How we meet this control

<!--
  REQUIRED. Describe what is in place today, present tense. Cover:
    - Where this service's configuration lives (IaC, Helm values, app
      config files) and the single source of truth for each.
    - How secure baselines are defined — hardened base images, CIS-aligned
      modules, org-standard Terraform modules.
    - How configuration changes flow: same PR + review + CI path as code,
      or something else?
-->

## How it is enforced and monitored

<!--
  REQUIRED. Controls that rely on people remembering things fail
  audits. Cover:
    - Drift detection: does anything compare running state against
      declared state (terraform plan in CI, AWS Config, kube admission
      controllers)?
    - Can configuration be changed outside the pipeline (console access,
      kubectl edit)? If yes, how is that detected or prevented?
    - Policy-as-code checks (OPA, Checkov, tfsec) that block insecure
      configuration at PR time.
-->

## Scope and exclusions

<!--
  REQUIRED. Define the boundary honestly — a clear exclusion reads far
  better than a discovered omission. Consider:
    - List which environments' configuration is managed from this repo and
      which are managed elsewhere.
    - Secrets are configuration too — state where they live and cross-
      reference A.8.12 rather than repeating it.
    - Which environments are covered (prod only? staging too?)
    - Accepted risks, with a link to the risk register entry if one exists.
-->

## Gaps and remediation

<!--
  REQUIRED — write "None identified." if genuinely none.
  Use task-list checkboxes so open items are machine-trackable.
-->

- [ ] Example gap — owner: @username, due: 2026-12-31, tracking: ORG-1234

## Operational notes

<!--
  OPTIONAL. Runbooks, renewal dates, known quirks, past audit findings
  and how they were resolved.
-->

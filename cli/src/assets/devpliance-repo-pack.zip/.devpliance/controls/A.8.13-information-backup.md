---
template_version: 1

control_id: "A.8.13"
control_name: "Information backup"
theme: technological

status: planned                     # implemented | partial | planned | not_applicable
last_reviewed: 2026-07-22           # YYYY-MM-DD — update whenever content changes
review_cycle: annual                # quarterly | biannual | annual

# Systems, services, or repos this control applies to.
# Use the canonical names from your service catalogue.
applies_to:
  - example-service

related_controls: ["A.8.10", "A.8.24"]
tags: [backup, recovery]
---

# A.8.13 — Information backup

> **Control intent**
>
> Backup copies of information, software and systems must be maintained
> and regularly tested in accordance with an agreed backup policy, so that
> data and services can be recovered after loss, corruption or compromise.

<!--
  Write for two audiences: an auditor who has never seen your system,
  and the engineer who inherits this control next year. Be concrete —
  name the tools, link the configs. These comments are stripped at
  parse time; delete them as you go or leave them, either is fine.
-->

## How we meet this control

<!--
  REQUIRED. Describe what is in place today, present tense. Cover:
    - What is backed up for this service (each datastore), how (snapshots,
      PITR, dumps), and on what schedule.
    - Retention of backups, where they are stored (region, account
      isolation), and encryption of backups at rest.
    - The restore procedure and its owner — link the runbook.
-->

## How it is enforced and monitored

<!--
  REQUIRED. Controls that rely on people remembering things fail
  audits. Cover:
    - Restore testing: when a restore was last actually performed, whether
      it is scheduled, and the measured RTO/RPO against targets.
    - Backup failure alerting, and protection of backups from deletion by
      a compromised production credential (separate account,
      immutability/object-lock).
-->

## Scope and exclusions

<!--
  REQUIRED. Define the boundary honestly — a clear exclusion reads far
  better than a discovered omission. Consider:
    - State what is deliberately not backed up (caches, derived data) and
      why that is acceptable.
    - Which environments are covered (prod only? staging too?)
    - Accepted risks, with a link to the risk register entry if one exists.
-->

## Gaps and remediation

<!--
  REQUIRED — write "None identified." if genuinely none.
  Use task-list checkboxes so open items are machine-trackable.
-->

- [ ] Example gap — owner: @username, due: 2026-12-31, tracking: ORG-1234

## Operational notes

<!--
  OPTIONAL. Runbooks, renewal dates, known quirks, past audit findings
  and how they were resolved.
-->

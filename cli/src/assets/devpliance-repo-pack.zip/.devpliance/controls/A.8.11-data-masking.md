---
template_version: 1

control_id: "A.8.11"
control_name: "Data masking"
theme: technological

status: planned                     # implemented | partial | planned | not_applicable
last_reviewed: 2026-07-22           # YYYY-MM-DD — update whenever content changes
review_cycle: annual                # quarterly | biannual | annual

# Systems, services, or repos this control applies to.
# Use the canonical names from your service catalogue.
applies_to:
  - example-service

related_controls: ["A.8.33", "A.8.10"]
tags: [masking, pseudonymisation]
---

# A.8.11 — Data masking

> **Control intent**
>
> Data masking (or pseudonymisation/anonymisation) must be applied in line
> with the organisation's access control and business requirements, so
> that sensitive data is hidden or transformed where full values are not
> needed.

<!--
  Write for two audiences: an auditor who has never seen your system,
  and the engineer who inherits this control next year. Be concrete —
  name the tools, link the configs. These comments are stripped at
  parse time; delete them as you go or leave them, either is fine.
-->

## How we meet this control

<!--
  REQUIRED. Describe what is in place today, present tense. Cover:
    - Where this service masks or pseudonymises data: in UIs (partial
      display of PANs/emails), in lower environments, in analytics
      exports, in logs.
    - The techniques used per case: redaction, tokenisation, hashing,
      format-preserving masking.
    - If the service holds no data warranting masking, mark not_applicable
      with a one-line justification of what data it does hold.
-->

## How it is enforced and monitored

<!--
  REQUIRED. Controls that rely on people remembering things fail
  audits. Cover:
    - What prevents unmasked paths appearing: review checklist for new UI
      fields/exports, tests asserting masked output.
    - Who can unmask (see full values) and how that elevated access is
      gated and logged.
-->

## Scope and exclusions

<!--
  REQUIRED. Define the boundary honestly — a clear exclusion reads far
  better than a discovered omission. Consider:
    - Masking in test environments overlaps A.8.33 — cross-reference
      rather than duplicating the answer.
    - Which environments are covered (prod only? staging too?)
    - Accepted risks, with a link to the risk register entry if one exists.
-->

## Gaps and remediation

<!--
  REQUIRED — write "None identified." if genuinely none.
  Use task-list checkboxes so open items are machine-trackable.
-->

- [ ] Example gap — owner: @username, due: 2026-12-31, tracking: ORG-1234

## Operational notes

<!--
  OPTIONAL. Runbooks, renewal dates, known quirks, past audit findings
  and how they were resolved.
-->

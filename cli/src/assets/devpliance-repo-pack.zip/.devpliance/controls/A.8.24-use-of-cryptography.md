---
template_version: 1

control_id: "A.8.24"
control_name: "Use of cryptography"
theme: technological

status: planned                     # implemented | partial | planned | not_applicable
last_reviewed: 2026-07-22           # YYYY-MM-DD — update whenever content changes
review_cycle: annual                # quarterly | biannual | annual

# Systems, services, or repos this control applies to.
# Use the canonical names from your service catalogue.
applies_to:
  - example-service

related_controls: ["A.8.12", "A.8.13"]
tags: [encryption, tls, kms]
---

# A.8.24 — Use of cryptography

> **Control intent**
>
> Rules for the effective use of cryptography — including cryptographic
> key management across the full key lifecycle — must be defined and
> implemented, to protect the confidentiality, integrity and authenticity
> of information.

<!--
  Write for two audiences: an auditor who has never seen your system,
  and the engineer who inherits this control next year. Be concrete —
  name the tools, link the configs. These comments are stripped at
  parse time; delete them as you go or leave them, either is fine.
-->

## How we meet this control

<!--
  REQUIRED. Describe what is in place today, present tense. Cover:
    - Data in transit: TLS versions and where termination happens;
      internal service-to-service encryption (mTLS, service mesh) or its
      absence.
    - Data at rest: what is encrypted, with what (KMS keys, disk
      encryption, field-level crypto) — per datastore.
    - Key management: who controls the keys, rotation schedule and
      mechanism, where key policy is defined.
-->

## How it is enforced and monitored

<!--
  REQUIRED. Controls that rely on people remembering things fail
  audits. Cover:
    - What prevents weak configuration returning: TLS policy tested in CI,
      security-group rules, config scanning for unencrypted resources.
    - Certificate lifecycle: automated renewal, and alerting on expiry.
-->

## Scope and exclusions

<!--
  REQUIRED. Define the boundary honestly — a clear exclusion reads far
  better than a discovered omission. Consider:
    - Application-level crypto (password hashing, signed tokens) belongs
      here too — name the algorithms so an auditor doesn't have to read
      the code.
    - State explicitly where crypto responsibility is delegated to a
      managed service.
    - Which environments are covered (prod only? staging too?)
    - Accepted risks, with a link to the risk register entry if one exists.
-->

## Gaps and remediation

<!--
  REQUIRED — write "None identified." if genuinely none.
  Use task-list checkboxes so open items are machine-trackable.
-->

- [ ] Example gap — owner: @username, due: 2026-12-31, tracking: ORG-1234

## Operational notes

<!--
  OPTIONAL. Runbooks, renewal dates, known quirks, past audit findings
  and how they were resolved.
-->

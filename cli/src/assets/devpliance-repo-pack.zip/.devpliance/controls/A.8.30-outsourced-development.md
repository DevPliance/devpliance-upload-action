---
template_version: 1

control_id: "A.8.30"
control_name: "Outsourced development"
theme: technological

status: planned                     # implemented | partial | planned | not_applicable
last_reviewed: 2026-07-22           # YYYY-MM-DD — update whenever content changes
review_cycle: annual                # quarterly | biannual | annual

# Systems, services, or repos this control applies to.
# Use the canonical names from your service catalogue.
applies_to:
  - example-service

related_controls: ["A.8.4", "A.8.25"]
tags: [third-party, contractors]
---

# A.8.30 — Outsourced development

> **Control intent**
>
> Where system development is outsourced, the organisation must direct,
> monitor and review the activities of the external developers, so that
> outsourced work meets the same security requirements as internal
> development.

<!--
  Write for two audiences: an auditor who has never seen your system,
  and the engineer who inherits this control next year. Be concrete —
  name the tools, link the configs. These comments are stripped at
  parse time; delete them as you go or leave them, either is fine.
-->

## How we meet this control

<!--
  REQUIRED. Describe what is in place today, present tense. Cover:
    - Whether external contractors or agencies contribute to this repo at
      all — if not, mark this control not_applicable and say so in one
      line.
    - If yes: how their access is provisioned (separate accounts, time-
      boxed), and which parts of the codebase they work on.
    - Contractual/security requirements they work under (reference the
      org-level supplier controls rather than duplicating them).
-->

## How it is enforced and monitored

<!--
  REQUIRED. Controls that rely on people remembering things fail
  audits. Cover:
    - Review rules for external contributions — internal approval
      required, no self-merge, same CI gates.
    - Offboarding: how access removal is triggered when an engagement
      ends.
-->

## Scope and exclusions

<!--
  REQUIRED. Define the boundary honestly — a clear exclusion reads far
  better than a discovered omission. Consider:
    - Include indirect contributions: consultancy-delivered code imported
      wholesale, or contractor-maintained forks.
    - Which environments are covered (prod only? staging too?)
    - Accepted risks, with a link to the risk register entry if one exists.
-->

## Gaps and remediation

<!--
  REQUIRED — write "None identified." if genuinely none.
  Use task-list checkboxes so open items are machine-trackable.
-->

- [ ] Example gap — owner: @username, due: 2026-12-31, tracking: ORG-1234

## Operational notes

<!--
  OPTIONAL. Runbooks, renewal dates, known quirks, past audit findings
  and how they were resolved.
-->

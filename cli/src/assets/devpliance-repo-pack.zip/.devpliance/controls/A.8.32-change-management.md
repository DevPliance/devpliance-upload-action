---
template_version: 1

control_id: "A.8.32"
control_name: "Change management"
theme: technological

status: planned                     # implemented | partial | planned | not_applicable
last_reviewed: 2026-07-22           # YYYY-MM-DD — update whenever content changes
review_cycle: annual                # quarterly | biannual | annual

# Systems, services, or repos this control applies to.
# Use the canonical names from your service catalogue.
applies_to:
  - example-service

related_controls: ["A.8.25", "A.8.31", "A.8.19"]
tags: [change, deployment]
---

# A.8.32 — Change management

> **Control intent**
>
> Changes to information processing facilities and systems must be subject
> to change management procedures, so that changes are reviewed, approved,
> tested and traceable — and can be rolled back when they go wrong.

<!--
  Write for two audiences: an auditor who has never seen your system,
  and the engineer who inherits this control next year. Be concrete —
  name the tools, link the configs. These comments are stripped at
  parse time; delete them as you go or leave them, either is fine.
-->

## How we meet this control

<!--
  REQUIRED. Describe what is in place today, present tense. Cover:
    - How changes to this service are proposed, reviewed, approved and
      deployed — for most repos this is the PR + CI + CD pipeline;
      describe it concretely.
    - Rollback: how a bad change is reverted and how long it takes.
    - The emergency change process and how it differs from the normal
      path.
-->

## How it is enforced and monitored

<!--
  REQUIRED. Controls that rely on people remembering things fail
  audits. Cover:
    - The audit trail: where a deployed artifact can be traced back to a
      commit, PR, approver and pipeline run.
    - What prevents deploying code that hasn't gone through the pipeline
      (deploy permissions, artifact provenance/signing).
-->

## Scope and exclusions

<!--
  REQUIRED. Define the boundary honestly — a clear exclusion reads far
  better than a discovered omission. Consider:
    - Include non-code changes that alter behaviour: feature flags, config
      toggles, database migrations — state which follow this process.
    - Which environments are covered (prod only? staging too?)
    - Accepted risks, with a link to the risk register entry if one exists.
-->

## Gaps and remediation

<!--
  REQUIRED — write "None identified." if genuinely none.
  Use task-list checkboxes so open items are machine-trackable.
-->

- [ ] Example gap — owner: @username, due: 2026-12-31, tracking: ORG-1234

## Operational notes

<!--
  OPTIONAL. Runbooks, renewal dates, known quirks, past audit findings
  and how they were resolved.
-->

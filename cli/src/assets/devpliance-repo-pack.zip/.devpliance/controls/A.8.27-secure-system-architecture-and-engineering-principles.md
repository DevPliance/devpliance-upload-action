---
template_version: 1

control_id: "A.8.27"
control_name: "Secure system architecture and engineering principles"
theme: technological

status: planned                     # implemented | partial | planned | not_applicable
last_reviewed: 2026-07-22           # YYYY-MM-DD — update whenever content changes
review_cycle: annual                # quarterly | biannual | annual

# Systems, services, or repos this control applies to.
# Use the canonical names from your service catalogue.
applies_to:
  - example-service

related_controls: ["A.8.26", "A.8.3"]
tags: [architecture, design]
---

# A.8.27 — Secure system architecture and engineering principles

> **Control intent**
>
> Principles for engineering secure systems must be established,
> documented, maintained and applied to all development activities — e.g.
> least privilege, defence in depth, secure defaults, and minimal attack
> surface, applied consistently at the architecture level.

<!--
  Write for two audiences: an auditor who has never seen your system,
  and the engineer who inherits this control next year. Be concrete —
  name the tools, link the configs. These comments are stripped at
  parse time; delete them as you go or leave them, either is fine.
-->

## How we meet this control

<!--
  REQUIRED. Describe what is in place today, present tense. Cover:
    - The service's trust boundaries: what sits in front of it, what it
      trusts implicitly, where authn/authz happen.
    - Applied principles with concrete examples — least privilege (IAM
      roles per component), defence in depth, fail-secure defaults,
      minimal attack surface.
    - Where the architecture is documented (diagram, ADRs) and how it is
      kept current.
-->

## How it is enforced and monitored

<!--
  REQUIRED. Controls that rely on people remembering things fail
  audits. Cover:
    - How architectural decisions are reviewed — ADR process, architecture
      review board, security sign-off for boundary changes.
    - Anything that verifies the principles in practice: IAM policy
      linting, network policy tests, periodic architecture review.
-->

## Scope and exclusions

<!--
  REQUIRED. Define the boundary honestly — a clear exclusion reads far
  better than a discovered omission. Consider:
    - Third-party components inside the boundary (managed DBs, message
      brokers) — state which security properties are delegated to the
      provider.
    - Which environments are covered (prod only? staging too?)
    - Accepted risks, with a link to the risk register entry if one exists.
-->

## Gaps and remediation

<!--
  REQUIRED — write "None identified." if genuinely none.
  Use task-list checkboxes so open items are machine-trackable.
-->

- [ ] Example gap — owner: @username, due: 2026-12-31, tracking: ORG-1234

## Operational notes

<!--
  OPTIONAL. Runbooks, renewal dates, known quirks, past audit findings
  and how they were resolved.
-->

---
template_version: 1

control_id: "A.8.4"
control_name: "Access to source code"
theme: technological

status: planned                     # implemented | partial | planned | not_applicable
last_reviewed: 2026-07-22           # YYYY-MM-DD — update whenever content changes
review_cycle: annual                # quarterly | biannual | annual

# Systems, services, or repos this control applies to.
# Use the canonical names from your service catalogue.
applies_to:
  - example-service

related_controls: ["A.8.2", "A.8.25"]
tags: [access-control, source-code]
---

# A.8.4 — Access to source code

> **Control intent**
>
> Read and write access to source code, development tools and software
> libraries must be appropriately managed and restricted, to prevent
> unauthorised changes, protect intellectual property, and preserve the
> integrity of what gets built and shipped.

<!--
  Write for two audiences: an auditor who has never seen your system,
  and the engineer who inherits this control next year. Be concrete —
  name the tools, link the configs. These comments are stripped at
  parse time; delete them as you go or leave them, either is fine.
-->

## How we meet this control

<!--
  REQUIRED. Describe what is in place today, present tense. Cover:
    - Who has read / write / admin on this repo, and how that maps to
      roles or teams (not individuals).
    - Branch protection on default and release branches: required reviews,
      required status checks, force-push and deletion restrictions.
    - CODEOWNERS coverage — which paths require which team's review.
    - How access is granted and revoked (joiner/leaver process, team sync
      from IdP).
-->

## How it is enforced and monitored

<!--
  REQUIRED. Controls that rely on people remembering things fail
  audits. Cover:
    - Is branch protection enforced for admins too, or can it be bypassed?
    - How often is repo access reviewed, and where is the review recorded?
    - Alerts or audit-log review for permission changes, deploy-key or PAT
      creation.
-->

## Scope and exclusions

<!--
  REQUIRED. Define the boundary honestly — a clear exclusion reads far
  better than a discovered omission. Consider:
    - Does this cover forks, mirrors, and any vendored copies of the code?
    - Machine access: deploy keys, GitHub Apps, CI tokens — list them and
      their scopes.
    - Which environments are covered (prod only? staging too?)
    - Accepted risks, with a link to the risk register entry if one exists.
-->

## Gaps and remediation

<!--
  REQUIRED — write "None identified." if genuinely none.
  Use task-list checkboxes so open items are machine-trackable.
-->

- [ ] Example gap — owner: @username, due: 2026-12-31, tracking: ORG-1234

## Operational notes

<!--
  OPTIONAL. Runbooks, renewal dates, known quirks, past audit findings
  and how they were resolved.
-->

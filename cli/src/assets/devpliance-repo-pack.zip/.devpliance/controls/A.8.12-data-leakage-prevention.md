---
template_version: 1

control_id: "A.8.12"
control_name: "Data leakage prevention"
theme: technological

status: planned                     # implemented | partial | planned | not_applicable
last_reviewed: 2026-07-22           # YYYY-MM-DD — update whenever content changes
review_cycle: annual                # quarterly | biannual | annual

# Systems, services, or repos this control applies to.
# Use the canonical names from your service catalogue.
applies_to:
  - example-service

related_controls: ["A.8.15", "A.8.33"]
tags: [secrets, dlp]
---

# A.8.12 — Data leakage prevention

> **Control intent**
>
> Data leakage prevention measures must be applied to systems, networks
> and devices that process, store or transmit sensitive information, to
> detect and prevent unauthorised disclosure or exfiltration of that
> information.

<!--
  Write for two audiences: an auditor who has never seen your system,
  and the engineer who inherits this control next year. Be concrete —
  name the tools, link the configs. These comments are stripped at
  parse time; delete them as you go or leave them, either is fine.
-->

## How we meet this control

<!--
  REQUIRED. Describe what is in place today, present tense. Cover:
    - Secret scanning on this repo: push protection, pre-commit hooks, the
      tools in use and what they catch.
    - How secrets are actually supplied to the service instead (secrets
      manager, CI secret store) — the safe path that makes the blocked
      path unnecessary.
    - Any egress controls relevant to this service: what external
      destinations it can talk to.
-->

## How it is enforced and monitored

<!--
  REQUIRED. Controls that rely on people remembering things fail
  audits. Cover:
    - The response when a secret does land in git history: rotation-first
      policy, history rewrite decision, incident record.
    - Are scanning rules tuned for your custom token formats, or only the
      default patterns?
-->

## Scope and exclusions

<!--
  REQUIRED. Define the boundary honestly — a clear exclusion reads far
  better than a discovered omission. Consider:
    - Logs and error messages are a leakage path too — cross-reference
      A.8.15 for scrubbing rather than duplicating it.
    - Which environments are covered (prod only? staging too?)
    - Accepted risks, with a link to the risk register entry if one exists.
-->

## Gaps and remediation

<!--
  REQUIRED — write "None identified." if genuinely none.
  Use task-list checkboxes so open items are machine-trackable.
-->

- [ ] Example gap — owner: @username, due: 2026-12-31, tracking: ORG-1234

## Operational notes

<!--
  OPTIONAL. Runbooks, renewal dates, known quirks, past audit findings
  and how they were resolved.
-->

---
template_version: 1

control_id: "A.8.29"
control_name: "Security testing in development and acceptance"
theme: technological

status: planned                     # implemented | partial | planned | not_applicable
last_reviewed: 2026-07-22           # YYYY-MM-DD — update whenever content changes
review_cycle: annual                # quarterly | biannual | annual

# Systems, services, or repos this control applies to.
# Use the canonical names from your service catalogue.
applies_to:
  - example-service

related_controls: ["A.8.28", "A.8.33"]
tags: [testing, sast, dast]
---

# A.8.29 — Security testing in development and acceptance

> **Control intent**
>
> Security testing processes must be defined and implemented across the
> development life cycle, verifying — in development and at acceptance —
> that security requirements are actually met, not merely specified.

<!--
  Write for two audiences: an auditor who has never seen your system,
  and the engineer who inherits this control next year. Be concrete —
  name the tools, link the configs. These comments are stripped at
  parse time; delete them as you go or leave them, either is fine.
-->

## How we meet this control

<!--
  REQUIRED. Describe what is in place today, present tense. Cover:
    - The security test types running against this repo: SAST,
      dependency/SCA scanning, container image scanning, DAST against a
      deployed environment, IaC scanning.
    - Where each runs (PR, merge to main, nightly, pre-release) and links
      to the CI definitions.
    - Security-relevant functional tests: authz tests per endpoint,
      tenant-isolation tests, input-validation tests.
-->

## How it is enforced and monitored

<!--
  REQUIRED. Controls that rely on people remembering things fail
  audits. Cover:
    - Failure policy per scan type: what blocks, what warns, who triages
      findings and within what SLA.
    - How coverage is prevented from silently degrading (required checks,
      scheduled-run alerting on failure).
-->

## Scope and exclusions

<!--
  REQUIRED. Define the boundary honestly — a clear exclusion reads far
  better than a discovered omission. Consider:
    - Pen tests are usually org-level — reference the programme and the
      last test that covered this service rather than restating it.
    - Which environments are covered (prod only? staging too?)
    - Accepted risks, with a link to the risk register entry if one exists.
-->

## Gaps and remediation

<!--
  REQUIRED — write "None identified." if genuinely none.
  Use task-list checkboxes so open items are machine-trackable.
-->

- [ ] Example gap — owner: @username, due: 2026-12-31, tracking: ORG-1234

## Operational notes

<!--
  OPTIONAL. Runbooks, renewal dates, known quirks, past audit findings
  and how they were resolved.
-->
